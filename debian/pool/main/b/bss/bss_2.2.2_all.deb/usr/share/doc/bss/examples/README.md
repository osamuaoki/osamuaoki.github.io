# Examples

This examples/ directory contains a set of configuration examples and scripts
on my note PC which is a bit more complicated than one explained in
bss_tutorial.md.

There are a few additional tricks I added:

* `secret-tool`: this is used to store my account name.  So I don't need to
  publish it in my shell script.
* `notify-send`: this helps user with the situation awareness of the slow
  background processes.

