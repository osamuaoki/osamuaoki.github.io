# sourced at the end of ~/.bashrc
# vim:set et sw=4 sts=4:

# User Private Groups: http://wiki.debian.org/UserPrivateGroups
umask 002

# make core file
ulimit -c unlimited

# stop beep
stty stop undef
