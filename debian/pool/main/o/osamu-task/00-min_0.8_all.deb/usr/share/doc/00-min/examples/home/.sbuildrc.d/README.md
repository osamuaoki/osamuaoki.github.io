# sbuild configuration

Create symlink from ~/.sbuildrc to use one of these configuration files.


* `bin`    -- build binary changes (initial, security, ...) with package test
* `src`    -- build source changes (normal) with package test
* `notest` -- build source changes (normal) without package test
            (just test build of source tree in chroot)

