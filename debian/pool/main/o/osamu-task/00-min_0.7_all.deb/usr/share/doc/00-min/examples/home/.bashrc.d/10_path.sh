# sourced at the end of ~/.bashrc
# vim:set et sw=4 sts=4:
# set CDPATH
#export CDPATH=.:~:/usr/share/doc
export CDPATH=.:~:/usr/share

# set PATH of normal users to include "sbin"
PATH="${PATH}":/usr/sbin:/sbin
