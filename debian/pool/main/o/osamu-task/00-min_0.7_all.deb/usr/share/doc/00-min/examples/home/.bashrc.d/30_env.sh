# sourced at the end of ~/.bashrc
# vim:set et sw=4 sts=4:

##############################################################################
# ENVIRONMENT VARIABLES, and EXPORT
##############################################################################

#export BROWSER=firefox
export BROWSER=chromium

#export MKISOFS="mkisofs"
export MKISOFS="xorrisofs"
