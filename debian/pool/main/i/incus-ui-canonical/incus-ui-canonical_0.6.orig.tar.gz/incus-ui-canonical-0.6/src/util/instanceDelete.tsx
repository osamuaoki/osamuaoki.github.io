import { LxdInstanceStatus } from "types/instance";

export const deletableStatuses: LxdInstanceStatus[] = ["Error", "Stopped"];
