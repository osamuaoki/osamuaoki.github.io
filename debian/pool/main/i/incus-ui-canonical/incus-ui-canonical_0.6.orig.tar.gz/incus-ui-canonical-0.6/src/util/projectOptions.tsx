export const optionAllowBlock = [
  {
    label: "Select option",
    value: "",
    disabled: true,
  },
  {
    label: "Allow",
    value: "allow",
  },
  {
    label: "Block",
    value: "block",
  },
];

export const optionAllowIsolatedUnprivileged = [
  {
    label: "Select option",
    value: "",
    disabled: true,
  },
  {
    label: "Allow",
    value: "allow",
  },
  {
    label: "Isolated",
    value: "isolated",
  },
  {
    label: "Unprivileged",
    value: "unprivileged",
  },
];

export const optionAllowBlockManaged = [
  {
    label: "Select option",
    value: "",
    disabled: true,
  },
  {
    label: "Allow",
    value: "allow",
  },
  {
    label: "Block",
    value: "block",
  },
  {
    label: "Managed",
    value: "managed",
  },
];
