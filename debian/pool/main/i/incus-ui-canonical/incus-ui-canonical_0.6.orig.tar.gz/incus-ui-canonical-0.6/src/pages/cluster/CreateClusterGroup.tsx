import React, { FC } from "react";
import ClusterGroupForm from "pages/cluster/ClusterGroupForm";

const CreateClusterGroup: FC = () => {
  return <ClusterGroupForm />;
};

export default CreateClusterGroup;
