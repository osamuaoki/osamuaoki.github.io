export const RECENT_MAJOR_SERVER_VERSION = 5;
export const UI_VERSION = "0.6";
