export interface LxdCertificate {
  fingerprint: string;
  restricted: boolean;
  projects: string[];
}
