export interface IsoImage {
  name: string;
  pool: string;
}
